#include <pebble.h>
#include "pokedex.h"

// TODO: replace crude hack with https://github.com/smallstoneapps/data-processor ;)

#define KEY_REQUEST_TYPE 36
#define KEY_DISPLAY_MESSAGE 37

#define KEY_POKEMON_ID 0
#define KEY_POKEMON_EXPIRATION_TIME 1
#define KEY_POKEMON_DISTANCE 2
#define KEY_POKEMON_BEARING 3
#define KEY_POKEMON_SLOT 4
#define KEY_POKEMON_LATITUDE 5
#define KEY_POKEMON_LONGITUDE 6

#define KEY_USER_LATITUDE 7
#define KEY_USER_LONGITUDE 8


Window *splash, *list, *compass;
MenuLayer *menu;
StatusBarLayer *status_bar;
Layer *overlay;
char alert_text_buffer[100] = "";
char list_buffer[100] = "";
bool use_mock_data = false;

Layer *alert;
TextLayer *alertText;

//alert layer
BitmapLayer *alertBackgroundLayer;
GBitmap *alertBackground;

GBitmap *ui_top, *ui_bottom;

int compass_heading = 0;

int NUM_POKEMON = 0;

int team = 2;
#define TEAM_NONE 0
#define TEAM_VALOR 1
#define TEAM_MYSTIC 2
#define TEAM_INSTINCT 3

GFont custom_font;
typedef struct {
  int32_t lat;
  int32_t lon;
} user_struct;
user_struct user;

#define MAX_POKEMON 100
typedef struct {
  int dex;
  int32_t lat;
  int32_t lon;
  time_t expire_time;
} pokemon_struct;

pokemon_struct pokemon[MAX_POKEMON];


// function getBearing(myLatitude, myLongitude, pkmnLatitude, pkmnLongitude) {
// 	var bearing;

// 	var lat1 = myLatitude, lon1 = myLongitude;
// 	var lat2 = pkmnLatitude, lon2 = pkmnLongitude;

// 	//var dLat = toRadians(lat2-lat1);
// 	var dLon = toRadians(lon2-lon1);

// 	lat1 = toRadians(lat1);
// 	lat2 = toRadians(lat2);

// 	var y = Math.sin(dLon) * Math.cos(lat2);
// 	var x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);

// 	bearing = toDegrees(Math.atan2(y,x));
// 	if(bearing < 0) bearing = 360-Math.abs(bearing);

// 	console.log("Start Lat: " + lat1);
// 	console.log("Start Lon: " + lon1);
// 	console.log("End Lat: " + lat2);
// 	console.log("End Lon: " + lon2);
// 	console.log("Bearing: " + bearing);

// 	return bearing;
// }


static const GPathInfo MINI_COMPASS_INFO = {
  .num_points = 4,
  .points = (GPoint []) { {0,-9}, {-6,9}, {0,3}, {6,9} }
};

// ------------------------------------------------------------------------ //
//  GPS Functions
// ------------------------------------------------------------------------ //
// GPS Constants
// I convert all floating point GPS coordinates to 32bit integers

#define EARTH_RADIUS_IN_METERS 6378137
#define EARTH_CIRCUMFERENCE_IN_METERS 40075016
#define MAX_GPS_ANGLE 8388608    // Equivalent to 360 degrees

// 64bit GPS constants
#define EARTH_RADIUS_IN_METERS_64BIT 6378137LL
#define EARTH_CIRCUMFERENCE_IN_METERS_64BIT 40075016LL
#define MAX_GPS_ANGLE_64BIT 8388608LL
#define TRIG_MAX_RATIO_64BIT 65536LL  // I know it's 65535, but this is close enough

// static int get_bearing(int y, int x) {
//   return atan2_lookup(y, x);
// }

#define root_depth 10          // How many iterations square root function performs
int32_t  sqrt32(int32_t a) {int32_t b=a; for(int8_t i=0; i<root_depth; i++) b=(b+(a/b))/2; return b;} // Square Root

static int32_t gps_distance(int lat_distance_in_meters, int lon_distance_in_meters) {
  return sqrt32((lat_distance_in_meters*lat_distance_in_meters)+(lon_distance_in_meters*lon_distance_in_meters));
  
}


// Returns vertical distance (in meters) between two latitudes
static int32_t gps_lat_distance(int32_t lat1, int32_t lat2) {
  //int32_t lat_distance = EARTH_CIRCUMFERENCE_IN_METERS * (lat2 - lat1) / MAX_GPS_ANGLE;
  int32_t lat_distance = (
    (
      EARTH_CIRCUMFERENCE_IN_METERS_64BIT *
      (int64_t) (lat2 - lat1)
    ) / (
      MAX_GPS_ANGLE_64BIT
    )
  );
  return lat_distance;
}

// Returns horizontal distance (in meters) between two longitudinal points at a specific latitude
static int32_t gps_lon_distance(int32_t lat, int32_t lon1, int32_t lon2) {
  //return cos_lookup((map_lat/128)) * EARTH_CIRCUMFERENCE_IN_METERS * (pos_lon - map_lon) / (MAX_GPS_ANGLE * TRIG_MAX_RATIO);
  int32_t lon_distance = (
    (
      (int64_t) cos_lookup(lat/128) *
      EARTH_CIRCUMFERENCE_IN_METERS_64BIT *
      (int64_t) (lon2 - lon1)
    ) / (
      MAX_GPS_ANGLE_64BIT *
      TRIG_MAX_RATIO_64BIT
    )
  );
  return lon_distance;
}







// // based on @mathew's process_distance()
// function getDistance(myLatitude, myLongitude, pkmnLatitude, pkmnLongitude) {
//   var distance;

//   var lat1 = myLatitude, lon1 = myLongitude;
//   var lat2 = pkmnLatitude, lon2 = pkmnLongitude;

//   var dLat = toRadians(lat2-lat1);
//   var dLon = toRadians(lon2-lon1);

//   lat1 = toRadians(lat1);
//   lat2 = toRadians(lat2);

//   //var y = Math.sin(dLon) * Math.cos(lat2);
//   //var x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);

//   var a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon/2) * Math.sin(dLon/2);
//   var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

//   //distance = convert_units(c*3959);
//   // numeric (meters) for now since actual data doesn't appear to reach kms
//   distance = (c*3959) * 1.60934 * 1000;

// //   console.log("Start Lat: " + lat1);
// //   console.log("Start Lon: " + lon1);
// //   console.log("End Lat: " + lat2);
// //   console.log("End Lon: " + lon2);
// //   console.log("Distance: " + distance);

//   return distance;
// }

// function getBearing(myLatitude, myLongitude, pkmnLatitude, pkmnLongitude) {
//   var bearing;

//   var lat1 = myLatitude, lon1 = myLongitude;
//   var lat2 = pkmnLatitude, lon2 = pkmnLongitude;

//   //var dLat = toRadians(lat2-lat1);
//   var dLon = toRadians(lon2-lon1);

//   lat1 = toRadians(lat1);
//   lat2 = toRadians(lat2);

//   var y = Math.sin(dLon) * Math.cos(lat2);
//   var x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);

//   bearing = toDegrees(Math.atan2(y,x));
//   if(bearing < 0) bearing = 360-Math.abs(bearing);

// //   console.log("Start Lat: " + lat1);
// //   console.log("Start Lon: " + lon1);
// //   console.log("End Lat: " + lat2);
// //   console.log("End Lon: " + lon2);
// //   console.log("Bearing: " + bearing);

//   return bearing;
// }




void temp_draw(Layer *layer, GContext *ctx){
  graphics_context_set_fill_color(ctx, GColorCobaltBlue);
  graphics_fill_rect(ctx, GRect(0, 0, PBL_IF_RECT_ELSE(144, 180),16), 0, GCornerNone);

  #ifdef PBL_RECT
  graphics_context_set_stroke_color(ctx, GColorWhite);
  for(int i = 0; i < 144; i++){
    if(i%2 == 0) graphics_draw_pixel(ctx, GPoint(i, 15));
  }
  #endif


  graphics_context_set_compositing_mode(ctx, GCompOpSet);
  //ROB TODO: Remove hard-coded values
  graphics_draw_bitmap_in_rect(ctx, ui_top, GRect(PBL_IF_RECT_ELSE(0, 18), 16, 144, 11));
  graphics_draw_bitmap_in_rect(ctx, ui_bottom, GRect(PBL_IF_RECT_ELSE(0, 18), PBL_IF_RECT_ELSE(168, 180) - 11, 144, 11));

  graphics_context_set_text_color(ctx, GColorWhite);
  graphics_draw_text(ctx, "     ", fonts_get_system_font(FONT_KEY_GOTHIC_14), GRect(0,PBL_IF_RECT_ELSE(-2,2),PBL_IF_RECT_ELSE(144,180),16), GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);
}


void stopped(Animation *anim, bool finished, void *context){
  property_animation_destroy((PropertyAnimation*) anim);
}


void animate_layer(Layer *layer, GRect *start, GRect *finish, int duration, int delay){
  PropertyAnimation *anim = property_animation_create_layer_frame(layer, start, finish);

  animation_set_duration((Animation*) anim, duration);
  animation_set_delay((Animation*) anim, delay);

  AnimationHandlers handlers = {
    .stopped = (AnimationStoppedHandler) stopped
  };
  animation_set_handlers((Animation*) anim, handlers, NULL);

  animation_schedule((Animation*) anim);
}

void draw_pokemon(GContext *ctx, const Layer *cell_layer, MenuIndex *index, void *data){
  if(index->row == 0){
    graphics_context_set_fill_color(ctx, GColorWhite);
    graphics_fill_rect(ctx, layer_get_bounds(cell_layer), 0, GCornerNone);
    return;
  }

  if(menu_cell_layer_is_highlighted(cell_layer)){
    graphics_context_set_fill_color(ctx, GColorLightGray);
    graphics_fill_rect(ctx, layer_get_bounds(cell_layer), 0, GCornerNone);
    #ifndef PBL_COLOR
    graphics_context_set_stroke_color(ctx, GColorBlack);
    graphics_context_set_stroke_width(ctx, 2);
    graphics_draw_line(ctx, GPoint(2, 4), GPoint(2, 56));
    #endif
  }

//if dex is between 0 and 151:
  GBitmap *sprite = NULL;
  
  graphics_context_set_text_color(ctx, GColorBlack);
  if(NUM_POKEMON == 1 && pokemon[0].dex == 0) {
    if(pokemon[0].expire_time == 0)
      strncpy(list_buffer, "Loading...", sizeof(list_buffer));
    else
      strncpy(list_buffer, "No Pokemon", sizeof(list_buffer));
    
    sprite = gbitmap_create_with_resource(poke_images[0]);  // load sprite 0 (pokeball image)
  } else if(pokemon[index->row-1].dex < 151 && pokemon[index->row-1].dex>=0) {
    sprite = gbitmap_create_with_resource(poke_images[pokemon[index->row-1].dex]);

    time_t now = time(NULL);
    if(use_mock_data) now = 1469237853;
    
    int expiration_delta = pokemon[index->row-1].expire_time - now;
    if(expiration_delta < 0 && !use_mock_data) {
      strncpy(list_buffer, "Expired!", sizeof(list_buffer));
    } else {
      int y = gps_lat_distance(user.lat, pokemon[index->row-1].lat);
      int x = gps_lon_distance(user.lat, user.lon, pokemon[index->row-1].lon);
      int distance = gps_distance(y, x);
      //int bearing = get_bearing(y, x);
      int bearing = atan2_lookup(x, y);
      int heading = bearing  + compass_heading;

      snprintf(list_buffer, sizeof(list_buffer),
               "%s\n%d:%02d\n%d m",
               poke_names[pokemon[index->row-1].dex],
               expiration_delta / 60,
               expiration_delta % 60, distance
              );

      // draw compass
      GPath *compass = gpath_create(&MINI_COMPASS_INFO);
      gpath_move_to(compass, GPoint(124, 40));
      gpath_rotate_to(compass, heading);
      graphics_context_set_fill_color(ctx, GColorBlack);
      gpath_draw_filled(ctx, compass);
      gpath_destroy(compass);
    }
  }
  
  if (sprite) {
    GRect bounds = gbitmap_get_bounds(sprite);
    graphics_context_set_compositing_mode(ctx, GCompOpSet);
    graphics_draw_bitmap_in_rect(ctx, sprite, GRect(2+30-(bounds.size.w/2), 30-(bounds.size.h/2), bounds.size.w, bounds.size.h));
    gbitmap_destroy(sprite);
  }


  graphics_draw_text(ctx, list_buffer, custom_font, GRect(64, 14, 180, 30), GTextOverflowModeWordWrap, GTextAlignmentLeft, NULL);
}

static uint16_t get_num_pokemon(MenuLayer *menu_layer, uint16_t section_index, void *data){
  return NUM_POKEMON + 1;
}

static int16_t pokemon_cell_height(MenuLayer *menu_layer, MenuIndex *cell_index, void *data){
  if(cell_index->row == 0) return 20;
  return 60;
}

void down(ClickRecognizerRef ref, void *context) {
  MenuIndex current = menu_layer_get_selected_index(menu);
  if(current.row == NUM_POKEMON)
    return;
  else
    menu_layer_set_selected_next(menu, false, MenuRowAlignCenter, true);
}

void up(ClickRecognizerRef ref, void *context) {
  MenuIndex current = menu_layer_get_selected_index(menu);
  if(current.row == 1) return;
  else
    menu_layer_set_selected_next(menu, true, MenuRowAlignCenter, true);
}

void config(void *context) {
  window_single_repeating_click_subscribe(BUTTON_ID_DOWN, 200, down);
  window_single_repeating_click_subscribe(BUTTON_ID_UP, 200, up);
}


static void tick_handler(struct tm *tick_time, TimeUnits units_changed) {
  // call API on the 15s (for now until distance refresh implemented)
  //   if (tick_time->tm_sec % 15 == 0) {
  //     //APP_LOG(APP_LOG_LEVEL_INFO, "tick_handler() 0/15/30/45");

  //     // Begin dictionary
  //     DictionaryIterator *iter;
  //     app_message_outbox_begin(&iter);

  //     // RequestType is currently meaningless, but w/b used for e.g. "full" API call vs. distance refresh

  //     // Add key-value pairs
  //     dict_write_cstring(iter, KEY_REQUEST_TYPE, "");

  //     // Send the message!
  //     app_message_outbox_send();
  //   }


  // Iterate through all pokemon, remove old dead, update cell position


// Refresh countdown and compass once per second
  layer_mark_dirty(window_get_root_layer(list));
}

void displayToast(char *string) {
  static GRect from_frame, to_frame;
  from_frame =  GRect(PBL_IF_ROUND_ELSE(40, 22), 180, 100, 100);
  to_frame = GRect(PBL_IF_ROUND_ELSE(40, 22), 34, 100, 100);

  APP_LOG(APP_LOG_LEVEL_DEBUG, "Received Toast: \"%s\"", string);
  strncpy(alert_text_buffer, string, sizeof(alert_text_buffer));
  text_layer_set_text(alertText, alert_text_buffer);

  vibes_double_pulse();

  animate_layer(alert, &from_frame, &to_frame, 1000, 0);
  animate_layer(alert, &to_frame, &from_frame, 1000, 3000);
}

static void bluetooth_callback(bool connected) {
  if(connected) {
    displayToast("Bluetooth reconnected");
  } else {
    displayToast("Bluetooth disconnected");
  }
}


static void inbox_received_callback(DictionaryIterator *iterator, void *context) {
  // TODO: use https://github.com/smallstoneapps/data-processor instead of this quick crude hack!
  //  APP_LOG(APP_LOG_LEVEL_INFO, "App Message received!");

  Tuple *display_message_tuple,
  *pokemon_id_tuple,
  *pokemon_expiration_tuple,
  *pokemon_distance_tuple,
  *pokemon_bearing_tuple,
  *pokemon_latitude_tuple,
  *pokemon_longitude_tuple,
  *user_latitude_tuple,
  *user_longitude_tuple;


  // If app message is: a DISPLAY MESSAGE
  if ((display_message_tuple = dict_find(iterator, KEY_DISPLAY_MESSAGE))) {
    if(display_message_tuple->value->cstring) {
      displayToast(display_message_tuple->value->cstring);
    }
  }

  // If app message is: USER GPS LOCATION
  if ((user_latitude_tuple = dict_find(iterator, KEY_USER_LATITUDE)) &&
      (user_longitude_tuple = dict_find(iterator, KEY_USER_LONGITUDE))) {
    user.lat = user_latitude_tuple->value->int32;
    user.lon = user_longitude_tuple->value->int32;
    APP_LOG(APP_LOG_LEVEL_DEBUG, "New User GPS: (%d, %d)", (int)user.lat, (int)user.lon);
  }
  

  // If app message is: A POKEMON
  if ((pokemon_id_tuple = dict_find(iterator, KEY_POKEMON_ID))) {
    int pokemon_id = pokemon_id_tuple->value->int32;
//     int pokemon_bearing = 0;
//     int pokemon_distance = -1;
    int pokemon_longitude = 0;
    int pokemon_latitude = 0;
    time_t now = time(NULL);
    if(use_mock_data) now = 1469237853;
    int pokemon_expiration = now;

    if ((pokemon_expiration_tuple = dict_find(iterator, KEY_POKEMON_EXPIRATION_TIME)))
      pokemon_expiration = pokemon_expiration_tuple->value->int32;

//     if ((pokemon_distance_tuple = dict_find(iterator, KEY_POKEMON_DISTANCE)))
//       pokemon_distance = pokemon_distance_tuple->value->int32;

//     if ((pokemon_bearing_tuple = dict_find(iterator, KEY_POKEMON_BEARING)))
//       pokemon_bearing = pokemon_bearing_tuple->value->int32;
    
    if ((pokemon_latitude_tuple = dict_find(iterator, KEY_POKEMON_LATITUDE)))
      pokemon_latitude = pokemon_latitude_tuple->value->int32;

    if ((pokemon_longitude_tuple = dict_find(iterator, KEY_POKEMON_LONGITUDE)))
      pokemon_longitude = pokemon_longitude_tuple->value->int32;

    
      
//     APP_LOG(APP_LOG_LEVEL_DEBUG,
//             "New Pokemon: ID %d (%d, %d), Dist:%d Bear:%d Exp: %d",
//             (int)pokemon_id,
//             (int)pokemon_latitude,
//             (int)pokemon_longitude,
//             (int)pokemon_distance,
//             (int)pokemon_bearing,
//             (int)(pokemon_expiration - now)
//            );
    
    int y = gps_lat_distance(user.lat, pokemon_latitude);
    int x = gps_lon_distance(user.lat, user.lon, pokemon_longitude);
    int distance = gps_distance(x, y);
    int bearing = atan2_lookup(y, x);
    //if(bearing < 0) bearing = TRIG_MAX_ANGLE + bearing;
    int heading = bearing  + compass_heading;

    APP_LOG(APP_LOG_LEVEL_DEBUG,
            "PEB Pokemon: ID %d (%d, %d), Dist:%d Bear:%d -- Pebble Calc'd",
            (int)pokemon_id,
            (int)pokemon_latitude,
            (int)pokemon_longitude,
            (int)distance,
            (int)bearing
           );

    if(NUM_POKEMON == 1 && pokemon[0].dex == 0) {  // If currently in "No pokemon" mode
      if (pokemon_id == 0) {         // Received a "no pokemon found" message
        pokemon[0].expire_time = 1;  // using expire_time to denote a message when dex=0
        return;
      } else {
        NUM_POKEMON = 0;  // id!=0: Get rid of "Loading..." or "No pokemon" message. We found pokemon!
      }
    }
    
    if (pokemon_id == 0) {
      APP_LOG(APP_LOG_LEVEL_DEBUG, "No additional pokemon found.");
      return;
    }
    
    if (pokemon_id <= 0 || pokemon_id > 151) {  // = 0 shouldn't happen, already caught above
      APP_LOG(APP_LOG_LEVEL_DEBUG, "ERROR! Pokemon ID = %d", (int)pokemon_id);
      return;
    }
    
    if ((pokemon_expiration < now) && !use_mock_data) {
      APP_LOG(APP_LOG_LEVEL_DEBUG, "ERROR! Pokemon expired!");
      return;
    }
    
    if(NUM_POKEMON == MAX_POKEMON) {  // If we've maxed out our list, then don't add it
      return;
    }
    
    // Add the new pokemon to the list!
    pokemon[NUM_POKEMON].dex = pokemon_id;
    pokemon[NUM_POKEMON].lat = pokemon_latitude;
    pokemon[NUM_POKEMON].lon = pokemon_longitude;
    pokemon[NUM_POKEMON].expire_time = pokemon_expiration;
    NUM_POKEMON++;
  }

  menu_layer_reload_data(menu);
}


static void inbox_dropped_callback(AppMessageResult reason, void *context) {
  APP_LOG(APP_LOG_LEVEL_ERROR, "Message dropped!");
}

static void outbox_failed_callback(DictionaryIterator *iterator, AppMessageResult reason, void *context) {
  APP_LOG(APP_LOG_LEVEL_ERROR, "Outbox send failed!");
}

static void outbox_sent_callback(DictionaryIterator *iterator, void *context) {
  APP_LOG(APP_LOG_LEVEL_INFO, "Outbox send success!");
}



void compass_handler(CompassHeadingData heading){
  compass_heading = heading.true_heading;
  // Commenting out below to save battery.  Tick timer already updates once per second.
  //layer_mark_dirty(window_get_root_layer(list));  // Refresh every time compass updates
  //layer_mark_dirty(window_get_root_layer(compass));  // TODO: Compass Window?
}


void init(){
  // Register callbacks
  app_message_register_inbox_received(inbox_received_callback);
  app_message_register_inbox_dropped(inbox_dropped_callback);
  app_message_register_outbox_failed(outbox_failed_callback);
  app_message_register_outbox_sent(outbox_sent_callback);

  // Open AppMessage
  // TODO: sizes?
  app_message_open(2048,2048);

  tick_timer_service_subscribe(SECOND_UNIT, tick_handler);

  connection_service_subscribe((ConnectionHandlers) {
    .pebble_app_connection_handler = bluetooth_callback
  });


  custom_font = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FONT_PKMN_10));

  ui_top = gbitmap_create_with_resource(RESOURCE_ID_UI_TOP);
  ui_bottom = gbitmap_create_with_resource(RESOURCE_ID_UI_BOTTOM);


  #ifdef PBL_COLOR
  GColor *pal_top = gbitmap_get_palette(ui_top);
  GColor *pal_bottom = gbitmap_get_palette(ui_bottom);

  switch(team){
    case TEAM_NONE:
    pal_top[0] = GColorDarkGray;
    pal_bottom[2] = GColorDarkGray;
    break;

    case TEAM_MYSTIC:
    pal_top[0] = GColorCobaltBlue;
    pal_bottom[2] = GColorCobaltBlue;
    break;

    case TEAM_INSTINCT:
    pal_top[0] = GColorOrange;
    pal_bottom[2] = GColorOrange;
    break;
  }
  #endif

  list = window_create();
  window_set_click_config_provider(list, config);
  window_set_background_color(list, GColorWhite);

  menu = menu_layer_create(GRect(0, 16, PBL_IF_RECT_ELSE(144,180), PBL_IF_RECT_ELSE(168,180) - 16));
  menu_layer_set_callbacks(menu, NULL, (MenuLayerCallbacks){
    .draw_row = draw_pokemon,
    .get_num_rows = get_num_pokemon,
    .get_cell_height = pokemon_cell_height,
  });
  //menu_layer_set_click_config_onto_window(menu, list);

  layer_add_child(window_get_root_layer(list), menu_layer_get_layer(menu));

  overlay = layer_create(layer_get_bounds(window_get_root_layer(list)));
  layer_set_update_proc(overlay, temp_draw);

  status_bar = status_bar_layer_create();
  int16_t width = layer_get_bounds(overlay).size.w;
  GRect frame = GRect(0, -1, width, STATUS_BAR_LAYER_HEIGHT); // -1 so the overlay still shows up beneath it
  layer_set_frame(status_bar_layer_get_layer(status_bar), frame);
  status_bar_layer_set_colors(status_bar, GColorCobaltBlue, GColorWhite);
  layer_add_child(overlay, status_bar_layer_get_layer(status_bar));


  layer_add_child(window_get_root_layer(list), overlay);

  // crude loading message
  NUM_POKEMON = 1;
  pokemon[0].dex = 0;
  pokemon[0].expire_time = 0;

  user.lat = 0; user.lon = 0;

  compass_service_subscribe(compass_handler);

  menu_layer_reload_data(menu);
  menu_layer_set_selected_index(menu, (MenuIndex){0,1}, MenuRowAlignNone, false);

  alert = layer_create(GRect(PBL_IF_ROUND_ELSE(40, 34), 200, 100, 100));

  alertText = text_layer_create(GRect(0, 0, 100, 100));
  text_layer_set_text(alertText, alert_text_buffer);
  text_layer_set_text_alignment(alertText, GTextAlignmentCenter);
  layer_add_child(alert, text_layer_get_layer(alertText));

  alertBackgroundLayer = bitmap_layer_create(GRect(0, 0, 100, 100));
  bitmap_layer_set_compositing_mode(alertBackgroundLayer, GCompOpSet);
  alertBackground = gbitmap_create_with_resource(RESOURCE_ID_ALERT_BACKGROUND);
  bitmap_layer_set_bitmap(alertBackgroundLayer, alertBackground);
  layer_add_child(alert, bitmap_layer_get_layer(alertBackgroundLayer));

  layer_add_child(overlay, alert);

  window_stack_push(list, true);
}


void deinit() {
  window_destroy(list);
  //window_destroy(compass);
  menu_layer_destroy(menu);
  layer_destroy(overlay);
  fonts_unload_custom_font(custom_font);
}


int main() {
  init();
  app_event_loop();
  deinit();
}